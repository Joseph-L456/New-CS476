!?!?
<?php

  	$username = "Welcome";



    $uid = "wut";
    if (isset($_GET["userid"])){
        $uid = $_GET["userid"];
    }

    echo $username;
    echo $uid;



?>