!?!?
<?php

  	$username = "Welcome";
    session_start();



    $username = $_SESSION["user_id"];
    $password = $_SESSION["user_id"];

    echo $username;
    echo $password;



?>