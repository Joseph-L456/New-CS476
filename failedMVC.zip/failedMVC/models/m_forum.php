<?php
require_once("../db/database.php");



class Topics
{

    protected $T_tid;
    protected $T_topicDate;
    protected $T_topicTitle;
    protected $T_topicContent;
    protected $T_replyNumber;
    protected $T_isDeleted;
    protected $T_rid;
    protected $T_uid;
    protected $T_username;
    private $dbConn;

    var $S_id;
    var $S_profilename;


    public function __construct($dbConn){
        $this->dbConn = $dbConn;

	}

    // GET METHODS
    public function getTtid()
    {
        return $this->T_tid;
    }

    public function getTtopicDate()
    {
        return $this->T_topicDate;
    }

    public function getTtopicTitle()
    {
        return $this->T_topicTitle;
    }

    public function getTtopicContent()
    {
        return $this->T_topicContent;
    }

    public function getTreplyNumber()
    {
        return $this->T_replyNumber;
    }

    public function getTisDeleted()
    {
        return $this->T_isDeleted;
    }

    public function getTrid()
    {
        return $this->T_rid;
    }

    public function getTuid()
    {
        return $this->T_uid;
    }

    public function getTusername()
    {
        return $this->T_username;
    }

 
    // SET METHODS
    public function setTtid(string $T_tid)
    {
        $this->T_tid = $T_tid;
    }

    public function setTtopicDate(string $T_topicDate)
    {
        $this->T_topicDate = $T_topicDate;
    }

    public function setTtopicTitle(string $T_topicTitle)
    {
        $this->T_topicTitle = $T_topicTitle;
    }

    public function setTtopicContent(string $T_topicContent)
    {
        $this->T_topicContent = $T_topicContent;
    }
    
    public function setTreplyNumber(string $T_replyNumber)
    {
        $this->T_replyNumber = $T_replyNumber;
    }

    public function setTisDeleted(string $T_isDeleted)
    {
        $this->T_isDeleted = $T_isDeleted;
    }

    public function setTrid(string $T_rid)
    {
        $this->T_rid = $T_rid;
    }

    public function setTuid(string $T_uid)
    {
        $this->T_uid = $T_uid;
    }

    public function setTusername(string $T_username)
    {
        $this->T_username = $T_username;
    }

    


    //Funtions
    public function defaultForumDisplay()
    {
        $tpselect = "SELECT Topics.tid, Topics.topicDate, Topics.topicTitle, Topics.topicContent, Topics.replyNumber, Topics.isDeleted, Usernames.uid, Usernames.profileName FROM Topics 
		INNER JOIN Usernames ON (Topics.uid = Usernames.uid)
        WHERE Topics.tid = (SELECT MAX(Topics.tid) FROM Topics)
	  	ORDER BY Topics.tid DESC;";

        $result = $this->dbConn->query($tpselect);

        if($result->rowCount() > 0){
	        $row = $result->fetch();

	        $this->T_tid =$row["tid"];
	        $this->T_topicDate = $row["topicDate"];
            $this->T_topicTitle = $row["topicTitle"];
            $this->T_topicContent =$row["topicContent"];
            $this->T_replyNumber =$row["replyNumber"];
            $this->T_isDeleted =$row["isDeleted"];
	        $this->T_uid = $row["uid"];
            $this->T_username = $row["profileName"];


        }
        else{
            print_r("default error");
        }

    }

    public function loopForumDisplay($counter)
    {

        $tpselect = "SELECT Topics.tid, Topics.topicDate, Topics.topicTitle, Topics.topicContent, Topics.replyNumber, Topics.isDeleted, Usernames.uid, Usernames.profileName FROM Topics 
		INNER JOIN Usernames ON (Topics.uid = Usernames.uid)
        WHERE Topics.tid = $counter
	  	ORDER BY Topics.tid DESC;";
    
        $result = $this->dbConn->query($tpselect);

        if($result->rowCount() > 0){
	        $row = $result->fetch();

	        $this->T_tid =$row["tid"];
	        $this->T_topicDate = $row["topicDate"];
            $this->T_topicTitle = $row["topicTitle"];
            $this->T_topicContent =$row["topicContent"];
            $this->T_replyNumber =$row["replyNumber"];
            $this->T_isDeleted =$row["isDeleted"];
	        $this->T_uid = $row["uid"];
            $this->T_username = $row["profileName"];

        }
        else{
            print_r("loop error");
        }
        $select = "SELECT Usernames.uid, Usernames.profileName FROM Usernames WHERE uid = 2";
    
        $pfresult = $this->dbConn->query($select);

        if($pfresult->rowCount() > 0){
	        $row = $pfresult->fetch();

	        $this->S_id =$row["uid"];
	        $this->S_profilename = $row["profileName"];


        }

    }


    public function setSessionID($id)
    {
        $pfselect = "SELECT Usernames.uid, Usernames.profileName FROM Usernames WHERE uid = $id;";
        $pfresult = $this->dbConn->query($pfselect);
        $row = $pfresult->fetch();

        $this->S_id = $row["uid"];
        $this->S_profilename = $row["profileName"];
    }
}









$g_instance = DbconnSingleton::getInstance();  // getinstance new dbconn static method
$g_conn = $g_instance->getConnection();