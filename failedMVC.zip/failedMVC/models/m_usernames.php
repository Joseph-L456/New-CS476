<?php
require_once("../db/database.php");




class Usernames
{
    protected $U_uid;
    protected $U_email;
    protected $U_password;
    protected $U_profileName;
    protected $U_accountType;
    protected $U_description;
    protected $U_avatar;
    protected $U_topicCount;
    protected $U_replyCount;
    protected $U_artworkCount;
    protected $U_tid;
    protected $U_rid;
    protected $U_aid;
    private $dbConn;

    var $S_id;
    var $S_profilename;


    public function __construct($dbConn){
        $this->dbConn = $dbConn;

	}
    // GET METHODS
    public function getUuid()
    {
        return $this->U_uid;
    }

    public function getUemail()
    {
        return $this->U_email;
    }

    public function getUpassword()
    {
        return $this->U_password;
    }

    public function getUprofileName()
    {
        return $this->U_profileName;
    }

    public function getU_accountType()
    {
        return $this->U_accountType;
    }

    public function getUdescription()
    {
        return $this->U_description;
    }

    public function getUavatar()
    {
        return $this->U_avatar;
    }

    public function getUtopicCount()
    {
        return $this->U_topicCount;
    }

    public function getUreplyCount()
    {
        return $this->U_replyCount;
    }

    public function getUartworkCount()
    {
        return $this->U_artworkCount;
    }

    public function getUrid()
    {
        return $this->U_rid;
    }

    public function getUaid()
    {
        return $this->U_aid;
    }


 
    // SET METHODS
    public function setUuid(string $U_uid)
    {
        $this->U_uid = $U_uid;
    }

    public function setUemail(string $U_email)
    {
        $this->U_email = $U_email;
    }

    public function setUpassword(string $U_password)
    {
        $this->U_password = $U_password;
    }

    public function setUprofileName(string $U_profileName)
    {
        $this->U_profileName = $U_profileName;
    }

    public function setUaccountType(string $U_accountType)
    {
        $this->U_accountType = $U_accountType;
    }

    public function setUdescription(string $U_description)
    {
        $this->U_description = $U_description;
    }

    public function setUavatar(string $U_avatar)
    {
        $this->U_avatar = $U_avatar;
    }

    public function setUtopicCount(string $U_topicCount)
    {
        $this->U_topicCount = $U_topicCount;
    }

    public function setUreplyCount(string $U_replyCount)
    {
        $this->U_replyCount = $U_replyCount;
    }

    public function setUartworkCount(string $U_artworkCount)
    {
        $this->U_artworkCount = $U_artworkCount;
    }

    public function setUtid(string $U_tid)
    {
        $this->U_tid = $U_tid;
    }

    public function setUrid(string $U_rid)
    {
        $this->U_rid = $U_rid;
    }

    public function setUaid(string $U_aid)
    {
        $this->U_aid = $U_aid;
    }



    //Funtions
    public function log(string $username, string $password)
    {
        $queryselect = "SELECT * FROM Usernames WHERE (email = '$username' AND password = '$password');";
	    $select = $this->dbConn->query($queryselect);

        if($select->rowCount() > 0)
        {
	        $credential = $select->fetch();
	  
	        $this->U_uid = $credential["uid"];
	        $this->U_email = $credential["email"];
            $this->U_password = $credential["password"];
            $this->U_profileName =$credential["profileName"];
	        $this->U_accountType = $credential["accountType"];
            $this->U_description = $credential["description"];
            $this->U_avatar =$credential["avatar"];
	        $this->U_topicCount = $credential["topicCount"];
            $this->U_replyCount = $credential["replyCount"];
            $this->U_tid =$credential["tid"];
	        $this->U_rid = $credential["rid"];
            $this->U_aid = $credential["aid"];
            $this->S_id = $credential["uid"];
            $this->S_profilename = $credential["profileName"];

        }
        else
        {
            print_r("error");
        }        
    }

    public function setName()
    {
        $id = $this->U_uid;
        $queryselect = "SELECT * FROM Usernames WHERE uid = '$id';";
	    $select = $this->dbConn->query($queryselect);
        if($select->rowCount() > 0){
	        $row = $select->fetch();
            $this->S_id = $row["uid"];
            $this->S_profilename = $row["profileName"];
        }


    }


    public function defaultProfileDisplay($id)
    {
        $tpselect = "SELECT * FROM Usernames WHERE uid = '$id';";

        $result = $this->dbConn->query($tpselect);

        if($result->rowCount() > 0){
	        $row = $result->fetch();

	        $this->U_uid = $row["uid"];
	        $this->U_email = $row["email"];
            $this->U_password = $row["password"];
            $this->U_profileName = $row["profileName"];
	        $this->U_accountType = $row["accountType"];
            $this->U_description = $row["description"];
            $this->U_avatar = $row["avatar"];
	        $this->U_topicCount = $row["topicCount"];
            $this->U_replyCount = $row["replyCount"];
            $this->U_tid = $row["tid"];
	        $this->U_rid = $row["rid"];
            $this->U_aid = $row["aid"];


        }
        else{
            print_r("default error");
        }

    }
}






$g_instance = DbconnSingleton::getInstance();  // getinstance new dbconn static method
$g_conn = $g_instance->getConnection();








?>
