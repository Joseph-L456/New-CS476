<?php
require_once("../db/database.php");
require_once("../controllers/c_login.php");


class Artworks
{
    protected $A_aid;
    protected $A_artworkName;
    protected $A_artworkDescription;
    protected $A_artworkImage;
    protected $A_uid;
    private $dbConn;

    var $S_id;
    var $S_profilename;


    public function __construct($dbConn){
        $this->dbConn = $dbConn;

	}

    // GET METHODS
    public function getAaid()
    {
        return $this->A_aid;
    }

    public function getA_artworkName()
    {
        return $this->A_artworkName;
    }

    public function getArtworkDescription()
    {
        return $this->A_artworkDescription;
    }

    public function getAartworkImage()
    {
        return $this->A_artworkImage;
    }

    public function getAuid()
    {
        return $this->A_uid;
    }

 
    // SET METHODS
    public function setAaid(string $A_aid)
    {
        $this->A_aid = $A_aid;
    }

    public function setAartworkName(string $A_artworkName)
    {
        $this->A_artworkName = $A_artworkName;
    }

    public function setAartworkDescription(string $A_artworkDescription)
    {
        $this->A_artworkDescription = $A_artworkDescription;
    }

    public function setAartworkImage(string $A_artworkImage)
    {
        $this->A_artworkImage = $A_artworkImage;
    }

    public function setAuid(string $A_uid)
    {
        $this->A_uid = $A_uid;
    }


    //Funtions
    public function defaultDisplay()
    {

        $awselect = "SELECT * FROM Artworks WHERE aid = (SELECT MAX(aid) FROM Artworks);";
    
        $awresult = $this->dbConn->query($awselect);

        if($awresult->rowCount() > 0){
	        $awrow = $awresult->fetch();

	        $this->A_aid =$awrow["aid"];
	        $this->A_artworkName = $awrow["artworkName"];
            $this->A_artworkDescription = $awrow["artworkDescription"];
            $this->A_artworkImage =$awrow["artworkImage"];
	        $this->A_uid = $awrow["uid"];

        }
        else{
            print_r("error");
        }

    }

    public function loopDisplay(int $counter)
    {

        $awselect = "SELECT * FROM Artworks WHERE aid = $counter";
    
        $awresult = $this->dbConn->query($awselect);

        if($awresult->rowCount() > 0){
	        $awrow = $awresult->fetch();

	        $this->A_aid =$awrow["aid"];
	        $this->A_artworkName = $awrow["artworkName"];
            $this->A_artworkDescription = $awrow["artworkDescription"];
            $this->A_artworkImage =$awrow["artworkImage"];
	        $this->A_uid = $awrow["uid"];
            print_r($awrow["aid"]);
            print_r($awrow["artworkName"]);
            print_r($this->A_artworkImage);

        }
        else{
            print_r("error");
        }

    }


}









$g_instance = DbconnSingleton::getInstance();  // getinstance new dbconn static method
$g_conn = $g_instance->getConnection();