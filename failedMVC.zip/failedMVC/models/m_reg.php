<?php
require_once("../db/database.php");
require_once("../controllers/c_signup.php");


class RegUsernames
{
    protected $U_uid;
    protected $U_email;
    protected $U_password;
    protected $U_profileName;
    protected $U_accountType;
    protected $U_description;
    protected $U_avatar;
    protected $U_topicCount;
    protected $U_replyCount;
    protected $U_artworkCount;
    protected $U_tid;
    protected $U_rid;
    protected $U_aid;
    private $dbConn;


    public function __construct($dbConn){
        $this->dbConn = $dbConn;

	}
    // GET METHODS
    public function getUuid()
    {
        return $this->U_uid;
    }

    public function getUemail()
    {
        return $this->U_email;
    }

    public function getUpassword()
    {
        return $this->U_password;
    }

    public function getUprofileName()
    {
        return $this->U_profileName;
    }

    public function getU_accountType()
    {
        return $this->U_accountType;
    }

    public function getUdescription()
    {
        return $this->U_description;
    }

    public function getUavatar()
    {
        return $this->U_avatar;
    }

    public function getUtopicCount()
    {
        return $this->U_topicCount;
    }

    public function getUreplyCount()
    {
        return $this->U_replyCount;
    }

    public function getUartworkCount()
    {
        return $this->U_artworkCount;
    }

    public function getUrid()
    {
        return $this->U_rid;
    }

    public function getUaid()
    {
        return $this->U_aid;
    }


 
    // SET METHODS
    public function setUuid(string $U_uid)
    {
        $this->U_uid = $U_uid;
    }

    public function setUemail(string $U_email)
    {
        $this->U_email = $U_email;
    }

    public function setUpassword(string $U_password)
    {
        $this->U_password = $U_password;
    }

    public function setUprofileName(string $U_profileName)
    {
        $this->U_profileName = $U_profileName;
    }

    public function setUaccountType(string $U_accountType)
    {
        $this->U_accountType = $U_accountType;
    }

    public function setUdescription(string $U_description)
    {
        $this->U_description = $U_description;
    }

    public function setUavatar(string $U_avatar)
    {
        $this->U_avatar = $U_avatar;
    }

    public function setUtopicCount(string $U_topicCount)
    {
        $this->U_topicCount = $U_topicCount;
    }

    public function setUreplyCount(string $U_replyCount)
    {
        $this->U_replyCount = $U_replyCount;
    }

    public function setUartworkCount(string $U_artworkCount)
    {
        $this->U_artworkCount = $U_artworkCount;
    }

    public function setUtid(string $U_tid)
    {
        $this->U_tid = $U_tid;
    }

    public function setUrid(string $U_rid)
    {
        $this->U_rid = $U_rid;
    }

    public function setUaid(string $U_aid)
    {
        $this->U_aid = $U_aid;
    }



    //Funtions

    public function reg(string $username, string $password, string $profilename)
    {        
        $queryselect = "SELECT * FROM Usernames WHERE (email = '$username');";
	    $select = $this->dbConn->query($queryselect);

        if($select->rowCount() > 0)
        {
            print_r("User exist.");
        }
        else if($username != NULL)
        {
            $queryinsert = "INSERT INTO Usernames(email, password, profileName) VALUES ('$username', '$password', '$profilename');";
            $insert = $this->dbConn->query($queryinsert);
            header("Location: ../index.html");
            
        }
        else
        {
            print_r("error");
        }
    }
}






$g_instance = DbconnSingleton::getInstance();  // getinstance new dbconn static method
$g_conn = $g_instance->getConnection();








?>
