<?php

require_once("../db/database.php");

require_once("../controllers/c_login.php");






class Product
{
    protected $id;
    protected $title;
    protected $description;
    protected $price;
    protected $sku;
    protected $image;
    private $dbConn;

    public function __construct($dbConn){
        $this->dbConn = $dbConn;

	}
    // GET METHODS
    public function getId()
    {
        return $this->id;
    }

    public function getTitle()
    {
        return $this->title;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function getPrice()
    {
        return $this->price;
    }

    public function getSku()
    {
        return $this->sku;
    }

    public function getImage()
    {
        return $this->image;
    }

    // SET METHODS
    public function setTitle(string $title)
    {
        $this->title = $title;
    }

    public function setDescription(string $description)
    {
        $this->description = $description;
    }

    public function setPrice(string $price)
    {
        $this->price = $price;
    }

    public function setSku(string $sku)
    {
        $this->sku = $sku;
    }

    public function setImage(string $image)
    {
        $this->image = $image;
    }

    // CRUD OPERATIONS
    public function create()
    {
  
        $queryinsert = "INSERT INTO products
        (title, description, image)
        VALUES
        ('2', 'test2', 'img_bg_1.jpg');";
	    $insert = $this->dbConn->query($queryinsert);
        return $insert;
        //my working but ugly code, contains business logic in the Model
    }

    public function read(int $id)
    {
        $queryselect = "SELECT Artworks.aid, Artworks.artworkName, Artworks.artworkDescription, Artworks.artworkImage FROM Artworks ORDER BY Artworks.aid DESC;";

        $awresult = $this->dbConn->query($queryselect);
        $rowCount = $awresult->rowCount();
        $aid = 0;
        $loopCounter = 0;

        while($rowCount > 0 && $loopCounter < 12){
            $row = $awresult->fetch();
                if($aid != $row["aid"]){
                    $this->title = $row["aid"];
                    $this->description = $row["aid"];
                    $this->price = $row["artworkImage"];
                    $this->sku = $row["artworkName"];
                    $this->image = $row["artworkDescription"];
                }
                return $this;







        //the code from materials, doesn't send the query to the database, and I don't know where to add the $this->dbConn->query($queryselect);

        }
    }

    public function log($username, $password)
    {

        $queryselect = "SELECT * FROM Usernames WHERE (email = '$username' AND password = '$password');";
	    $select = $this->dbConn->query($queryselect);


        if($select->rowCount() > 0){
	        $credential = $select->fetch();
	  
	        $this->title =$credential["uid"];
	        $this->title = $credential["profileName"];

            $this->description = $credential["accountType"];

            print_r("123341");
            print_r($this->title);
            print_r($this->description);
        }
        else{
            print_r("123341");
        }


        
    }


    public function update(int $id, array $data)
    {

    }

    public function delete(int $id)
    {

    }
}




$g_instance = DbconnSingleton::getInstance();  // getinstance new dbconn static method
$g_conn = $g_instance->getConnection();










?>
