<?php

class DbconnSingleton {

	private static $g_instance = NULL;
	private $g_conn = NULL;

	private $g_db_host = "localhost";
	private $g_db_username = "liu676";
	private $g_db_password = "Bl2ck.5";
	private $g_db_dbname = "liu676";
	private $g_charset = "utf8mb4";
	private $g_options = [
		PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
		PDO::ATTR_EMULATE_PREPARES   => false,
	];
	
	public function __construct(){
		$attr = "mysql:host={$this->g_db_host};dbname={$this->g_db_username};charset={$this->g_charset}";

		$this->g_conn = new PDO($attr, $this->g_db_username, $this->g_db_password, $this->g_options);
	}


	public static function getInstance() {
		if(!self::$g_instance){

			self::$g_instance = new DbconnSingleton();
		}
		return self::$g_instance;
	}



	public function getConnection() {
		try {
			return $this->g_conn;
		} 
		catch(PDOExeption $e){
		  // Echo error and Exception message
			throw new PDOException($e->getMessage(), (int)$e->getCode());
			}
		// If the try/catch block fails, echo that no connection was established
	}

}

class Session{

	private $sessionName;
	private $sessionID;

	function setSession($uid, $username)
	{
		session_start();

		$_SESSION["user_id"] = $uid;
		$_SESSION["name_of_user"] = $username; 

    }

	function keepSession($uid, $username)
	{
		session_start();

		$_SESSION["user_id"] = $uid;
		$_SESSION["name_of_user"] = $username; 
	}
}


  
?>
