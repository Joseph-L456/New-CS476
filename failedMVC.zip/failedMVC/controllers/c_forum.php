<?php
require_once("../db/database.php");
require_once("../models/m_forum.php");
require_once("../views/v_forum.php");
require_once("../models/m_usernames.php");


class Forum {

    private $dbConn;



    public function __construct($dbConn)
    {
        $this->dbConn = $dbConn;

	}



}


$userlogin = new Usernames($g_conn);
$forumdisplay = new Topics($g_conn);
$forum = new Forum($g_conn);
$forumgen = new ForumHTML($g_conn);

session_start();
$_SESSION["name_of_user"] = $userlogin->S_profilename;
$_SESSION["user_id"] = $userlogin->S_id;


$forumdisplay->defaultForumDisplay();


$forumgen->openPage();
$forumgen->readPage();
$counter = 0;
$tidcounter = $forumdisplay->getTtid();
while($counter < 12)
{
    $forumgen->editPage($counter, $forumdisplay->getTtid(), $forumdisplay->getTtopicDate(), $forumdisplay->getTtopicTitle(), 
    $forumdisplay->getTtopicContent(), $forumdisplay->getTreplyNumber(), $forumdisplay->getTusername());

    $counter++;
    $tidcounter--;
    $forumdisplay->loopForumDisplay($tidcounter);
}

$userlogin->setName();

$forumgen->editName($userlogin->getUuid(), $userlogin->getUprofileName());

print_r($userlogin->getUuid());



$forumgen->closePage();
$forumgen->writePage();
//header("Location: ../html/forum1.html");


?>















