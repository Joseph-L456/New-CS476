<?php
require_once("../models/m_usernames.php");
require_once("../db/database.php");

class DestroyS {

	function sessionDes(){



        if(isset($_SESSION))
        {
          unset($_SESSION);
        
       
          session_destroy();
           
    
          header("Location: ../index.html");
          sleep(1);
          exit();
        }
        else{
          header("Location: ../warning.php");
        }
	}
}
session_start();
$_SESSION["name_of_user"] = $userlogin->S_profilename;
$_SESSION["user_id"] = $userlogin->S_id;
$logout = new DestroyS();
$logout->sessionDes();


?>



