<?php
require_once("../db/database.php");
require_once("../models/m_usernames.php");
require_once("../views/v_profile.php");


class Profile {


    private $dbConn;



    public function __construct($dbConn)
    {
        $this->dbConn = $dbConn;

	}






}




$profiledisplay = new Usernames($g_conn);
$profile = new Profile($g_conn);
$profilegen = new ProfileHTML($g_conn);
$userlogin = new Usernames($g_conn);


session_start();
$_SESSION["name_of_user"] = $userlogin->S_profilename;
$_SESSION["user_id"] = $userlogin->S_id;






$profilegen->openPage();
$profilegen->readPage();

$profiledisplay->defaultProfileDisplay($userlogin->S_id);

$profilegen->editName($userlogin->S_id, $userlogin->S_id);






$profilegen->closePage();
$profilegen->writePage();
header("Location: ../html/profile1.html");


?>















