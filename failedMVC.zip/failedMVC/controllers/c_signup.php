<?php

require_once("../db/database.php");
require_once("../models/m_reg.php");




class Register 
{
    private $R_email;
    private $R_profileName;
    private $R_password;
    private $R_conpassword;
    private $dbConn;

    public function __construct($dbConn)
    {
        $this->dbConn = $dbConn;

	}

    function setRegCred()
    {
        $email = $_POST['uname1'];
        $pname = $_POST['pname1'];
        $password = $_POST['pswd1'];
        $confirmpassword = $_POST['pswdr1'];
        $this->R_email = $email;
        $this->R_profileName = $pname;
        $this->R_password = $password;
        $this->R_conpassword = $confirmpassword;
    }

    function getEmail()
    {

        return $this->R_email;

    }
    function getProfileName()
    {

        return $this->R_profileName;

    }

    function getPassword()
    {

        return $this->R_password;

    }

    function getConPassword()
    {

        return $this->R_conpassword;

    }


}


$g_instance = DbconnSingleton::getInstance();  // getinstance new dbconn static method
$g_conn = $g_instance->getConnection();



$newreg = new Register($g_conn);
$userReg = new RegUsernames($g_conn);


$newreg->setRegCred();
$userReg->reg($newreg->getEmail(), $newreg->getPassword(), $newreg->getProfileName());




?>















