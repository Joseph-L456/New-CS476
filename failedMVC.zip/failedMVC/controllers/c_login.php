<?php

require_once("../db/database.php");
require_once("../models/m_usernames.php");
require_once("../models/m_artworks.php");
require_once("../views/v_main.php");

class Login 
{
    private $L_email;
    private $L_password;
    private $dbConn;

    public function __construct($dbConn)
    {
        $this->dbConn = $dbConn;

	}

    function setCred()
    {
        $email = $_POST['uname'];
        $password = $_POST['pswd'];
        $this->L_email = $email;
        $this->L_password = $password;
    }



    function getEmail()
    {

        return $this->L_email;

    }

    function getPassword()
    {

        return $this->L_password;

    }

    function session($uid, $username)
    {

        $_SESSION["user_id"] = $uid;
        $_SESSION["name_of_user"] = $username;
        session_start();

    }




}


$g_instance = DbconnSingleton::getInstance();  // getinstance new dbconn static method
$g_conn = $g_instance->getConnection();



$newlogin = new Login($g_conn);
$userlogin = new Usernames($g_conn);
$maindisplay = new Artworks($g_conn);
$maingen = new MainHTML($g_conn);


$newlogin->setCred();
$userlogin->log($newlogin->getEmail(), $newlogin->getPassword());


unset($check);
$check = $userlogin->getU_accountType();

if(isset($check) == TRUE && $check == "0")
{
    $newlogin->session($userlogin->getUuid(), $userlogin->getUprofileName());
    $userlogin->S_id = $userlogin->getUuid();
    $userlogin->S_profilename = $userlogin->getUprofileName();
    $maindisplay->defaultdisplay();

    unset($awcheck);
    $awcheck = $maindisplay->getAaid();
    if(isset($awcheck) == TRUE)
    {
        $maingen->openPage();
        $maingen->readPage();
        $counter = 0;
        $aidcounter = $maindisplay->getAaid();
        while($counter < 12)
        {
            $maingen->editPage($counter, $maindisplay->getAaid(), $maindisplay->getAartworkImage(), $maindisplay->getA_artworkName(), $maindisplay->getArtworkDescription());
            $counter++;
            $aidcounter--;
            $maindisplay->loopdisplay($aidcounter);
        }
        $maingen->editName($userlogin->getUuid(), $userlogin->getUprofileName());
        $maingen->closePage();
        $maingen->writePage();

        header("Location: ../html/main1.html");

    }
    else
    {
        print_r("AW display error.");
    }
}
elseif(isset($check) == TRUE && $check == "1")
{
    $newlogin->session($userlogin->getUuid(), $userlogin->getUprofileName());
    $maindisplay->defaultdisplay();

    unset($awcheck);
    $awcheck = $maindisplay->getAaid();
    if(isset($awcheck) == TRUE)
    {
        $maingen->openAdminPage();
        $maingen->readAdminPage();
        $counter = 0;
        $aidcounter = $maindisplay->getAaid();
        while($counter < 12)
        {
            $maingen->editPage($counter, $maindisplay->getAaid(), $maindisplay->getAartworkImage(), $maindisplay->getA_artworkName(), $maindisplay->getArtworkDescription());
            $counter++;
            $aidcounter--;
            $maindisplay->loopdisplay($aidcounter);
        }
        $maingen->editName($userlogin->getUuid(), $userlogin->getUprofileName());
        $maingen->closePage();
        $maingen->writeAdminPage();
        header("Location: ../html/adminmain1.html");

    }
}
elseif(isset($check) == TRUE && $check == "2")
{
    print_r("Account is banned.");
}
else
{
    print_r("User does not exist.");
}





?>















