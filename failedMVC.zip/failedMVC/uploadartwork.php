<?php

require_once("database.php");



class UploadArtwork {
    var $g_email = "g_email";
    var $g_profileName = "g_password";
    var $g_description = "g_email";
    var $g_avatar = "g_password";
    var $g_topicCount = "g_email";
    var $g_replyCount = "g_password";
    var $g_artworkCount = "g_password";
    var $g_userid = "rewq";



  
	function setProf(){
        session_start();
        $proname = $_SESSION["name_of_user"];
        $userid = $_SESSION["user_id"];

        $pfselect = "SELECT Usernames.uid, Usernames.profileName FROM Usernames WHERE uid = '$userid'";
        $pfresult = $this->g_conn->query($pfselect);
        $row = $pfresult->fetch();

        $this->g_userid = $userid;
        $this->g_profileName = $row["profileName"];


        $queryselect = "SELECT artworkCount FROM Usernames WHERE Usernames.uid = $userid;";
        $select = $this->g_conn->query($queryselect);
        $row = $select->fetch();
        $postcounter = $row["artworkCount"];
        $postcounter++;


        $artworkname = $_POST['ulawname'];
        $artworkimage = $_POST['ulawimage'];
        $artworkdesc = $_POST['ulawdescription'];

        $queryinsert = "INSERT INTO Artworks(artworkName, artworkImage, artworkDescription, uid) VALUES ('$artworkname', '$artworkimage', '$artworkdesc', $userid);";
        $insert = $this->g_conn->query($queryinsert);

        $queryupdate = "UPDATE Usernames 
        SET artworkCount = '$postcounter'
        WHERE Usernames.uid = $userid;";
        $update = $this->g_conn->query($queryupdate);


        header("Location: uploadartwork1.html"); 

    }


}


$db = new Dbconn();
$db->setDb();
$db->openConnection();
$upla = new UploadArtwork();
$upla->g_conn=$db->g_conn;
$upla->setProf();



?>















