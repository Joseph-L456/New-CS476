var form = document.getElementById("Login");

form.addEventListener("submit", LoginForm, false);