var form1 = document.getElementById("Sign");

form1.addEventListener("submit", SignUpForm, false);