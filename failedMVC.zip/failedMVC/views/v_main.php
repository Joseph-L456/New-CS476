<?php
require_once("../db/database.php");
require_once("../controllers/c_login.php");


class MainHTML
{
    private $fp;
    private $str;
    private $dbConn;


    public function __construct($dbConn){
        $this->dbConn = $dbConn;

	}

    public function openPage()
    {
        $this->fp = fopen("../html/main.html","r");
        return $this->fp;
    }
    public function openAdminPage()
    {
        $this->fp = fopen("../html/adminmain.html","r");
        return $this->fp;
    }
    public function readPage()
    {
        $this->str=fread($this->fp,filesize("../html/main.html"));
        return $this->fp;
    }


    public function readAdminPage()
    {
        $this->str=fread($this->fp,filesize("../html/adminmain.html"));
        return $this->fp;
    }


    public function closePage()
    {
        fclose($this->fp);

    }

    public function writePage()
    {
        $handle = fopen('../html/main1.html',"w");
        fwrite($handle,$this->str);
        fclose($handle);
    }
    public function writeAdminPage()
    {
        $handle = fopen('../html/adminmain1.html',"w");
        fwrite($handle,$this->str);
        fclose($handle);
    }

    //Funtions
    public function editPage($counter, $id, $image, $name, $desc)
    {
        $this->str=str_replace("{awnumber$counter}", $id,$this->str);
        $this->str=str_replace("{awimage$counter}", $image, $this->str);
        $this->str=str_replace("{awname$counter}", $name, $this->str);
        $this->str=str_replace("{awdesc$counter}", $desc, $this->str);
        return $this->str;
    }

    public function editName($id, $name)
    {
        $this->str=str_replace("{userID}", $id, $this->str);
        $this->str=str_replace("{profileName}", $name, $this->str);
        return $this->str;
    }

}









$g_instance = DbconnSingleton::getInstance();  // getinstance new dbconn static method
$g_conn = $g_instance->getConnection();