<?php
require_once("../db/database.php");



class ProfileHTML
{
    private $fp;
    private $str;
    private $dbConn;


    public function __construct($dbConn){
        $this->dbConn = $dbConn;

	}

    public function openPage()
    {
        $this->fp = fopen("../html/profile.html","r");
        return $this->fp;
    }
    public function openAdminPage()
    {
        $this->fp = fopen("../html/adminprofile.html","r");
        return $this->fp;
    }
    public function readPage()
    {
        $this->str=fread($this->fp,filesize("../html/profile.html"));
        return $this->fp;
    }


    public function readAdminPage()
    {
        $this->str=fread($this->fp,filesize("../html/adminprofile.html"));
        return $this->fp;
    }


    public function closePage()
    {
        fclose($this->fp);

    }

    public function writePage()
    {
        $handle = fopen('../html/profile1.html',"w");
        fwrite($handle,$this->str);
        fclose($handle);
    }
    public function writeAdminPage()
    {
        $handle = fopen('../html/adminprofile1.html',"w");
        fwrite($handle,$this->str);
        fclose($handle);
    }

    //Funtions
    public function editPage($email, $proname, $desc, $avatar, $acount, $tcount, $rcount)
    {

        $this->str=str_replace("{profileName}", $email, $this->str);
        $this->str=str_replace("{email}", $proname, $this->str);
        $this->str=str_replace("{description}", $desc, $this->str);
        $this->str=str_replace("{avatar}", $avatar, $this->str);
        $this->str=str_replace("{topicCount}", $acount, $this->str);
        $this->str=str_replace("{replyCount}", $tcount, $this->str);
        $this->str=str_replace("{artworkCount}", $rcount, $this->str);

        return $this->str;
    }



    public function editName($id, $name)
    {
        $this->str=str_replace("{userID}", $id, $this->str);
        $this->str=str_replace("{profileName}", $name, $this->str);
        return $this->str;
    }


}









$g_instance = DbconnSingleton::getInstance();  // getinstance new dbconn static method
$g_conn = $g_instance->getConnection();