<?php
require_once("../db/database.php");



class ForumHTML
{
    private $fp;
    private $str;
    private $dbConn;


    public function __construct($dbConn){
        $this->dbConn = $dbConn;

	}

    public function openPage()
    {
        $this->fp = fopen("../html/forum.html","r");
        return $this->fp;
    }
    public function openAdminPage()
    {
        $this->fp = fopen("../html/adminforum.html","r");
        return $this->fp;
    }
    public function readPage()
    {
        $this->str=fread($this->fp,filesize("../html/forum.html"));
        return $this->fp;
    }


    public function readAdminPage()
    {
        $this->str=fread($this->fp,filesize("../html/adminforum.html"));
        return $this->fp;
    }


    public function closePage()
    {
        fclose($this->fp);

    }

    public function writePage()
    {
        $handle = fopen('../html/forum1.html',"w");
        fwrite($handle,$this->str);
        fclose($handle);
    }
    public function writeAdminPage()
    {
        $handle = fopen('../html/adminforum1.html',"w");
        fwrite($handle,$this->str);
        fclose($handle);
    }

    //Funtions
    public function editPage($counter, $tid, $topicDate, $topicTitle, $topicContent, $replyNumber, $author)
    {

        $this->str=str_replace("{tid$counter}",$tid, $this->str);
        $this->str=str_replace("{topicDate$counter}",$topicDate, $this->str);
        $this->str=str_replace("{topicTitle$counter}",$topicTitle, $this->str);
        $this->str=str_replace("{topicContent$counter}",$topicContent, $this->str);
        $this->str=str_replace("{replyNumber$counter}",$replyNumber, $this->str);
        $this->str=str_replace("{author$counter}",$author, $this->str);
        return $this->str;
    }



    public function editName($id, $name)
    {
        $this->str=str_replace("{userID}", $id, $this->str);
        $this->str=str_replace("{profileName}", $name, $this->str);
        return $this->str;
    }


}









$g_instance = DbconnSingleton::getInstance();  // getinstance new dbconn static method
$g_conn = $g_instance->getConnection();